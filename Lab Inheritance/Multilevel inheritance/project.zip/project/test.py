from project.sports_car import SportsCar

ferary = SportsCar()
print(ferary.race())
print(ferary.move())
print(ferary.drive())