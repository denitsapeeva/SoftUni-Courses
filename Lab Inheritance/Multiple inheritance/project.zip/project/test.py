from project.teacher import Teacher

Ivanka = Teacher()
print(Ivanka.teach())
print(Ivanka.get_fired())
print(Ivanka.sleep())